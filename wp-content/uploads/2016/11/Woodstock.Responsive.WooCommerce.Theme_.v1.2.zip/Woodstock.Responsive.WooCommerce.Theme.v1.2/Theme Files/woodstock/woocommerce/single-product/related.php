<?php
/**
 * Related Products
 *
 * @author      WooThemes
 * @package     WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

global $product, $woocommerce_loop;
$tdl_options = woodstock_global_var();
$related = $product->get_related( $posts_per_page );

if ( sizeof( $related ) == 0 ) return;

$args = apply_filters('woocommerce_related_products_args', array(
    'post_type'             => 'product',
    'ignore_sticky_posts'   => 1,
    'no_found_rows'         => 1,
    'posts_per_page'        => $posts_per_page,
    'orderby'               => $orderby,
    'post__in'              => $related,
    'post__not_in'          => array($product->id)
) );

$products = new WP_Query( $args );

$woocommerce_loop['columns'] = $columns;

if ( $products->have_posts() ) : ?>

    

    <?php $related_products_number = $products->post_count; ?>

    <?php if ( $related_products_number > 0 ) : ?>

        <div id="products-carousel">

        <h2 class="carousel-title"><?php esc_html_e( 'Related Products', 'woocommerce' ); ?></h2>

            <ul id="products" class="products products-grid product-layout-grid owl-carousel owl-theme">

                <?php while ( $products->have_posts() ) : $products->the_post(); ?>

                    <?php wc_get_template_part( 'content', 'product' ); ?>

                <?php endwhile; // end of the loop. ?>

            </ul>

        </div>

    <?php else : ?>
        <div class="related products">
                    
            <h2><?php esc_html_e( 'Related Products', 'woocommerce' ); ?></h2>    

            <ul id="products" class="products products-grid small-block-grid-2 medium-block-grid-<?php echo esc_attr($products_per_column_medium); ?> large-block-grid-<?php echo esc_attr($products_per_column_large); ?> xlarge-block-grid-<?php echo esc_attr($products_per_column_xlarge); ?> xxlarge-block-grid-<?php echo esc_attr($products_per_column); ?> columns-<?php echo esc_attr($products_per_column); ?> product-layout-grid">

                <?php while ( $products->have_posts() ) : $products->the_post(); ?>
                    <?php wc_get_template_part( 'content', 'product' ); ?>
                <?php endwhile; // end of the loop. ?>

            </ul>
        
        </div>
    <?php endif; ?>


    <?php
    
    if ( ( !isset($tdl_options['tdl_related_products_per_view']) ) ) {
        $related_products_per_view = 4;
    } else {
        $related_products_per_view = $tdl_options['tdl_related_products_per_view'];
    }
    
    ?>

    <script>
    jQuery(document).ready(function($) {

        "use strict";

        var owl = $('#products-carousel #products');
        owl.owlCarousel({
            items:<?php echo esc_attr($related_products_per_view); ?>,
            lazyLoad:true,
            dots:false,
            responsiveClass:true,
            nav:true,
            navText: [
                "",
                ""
            ],
            responsive:{
                0:{
                    items:2,
                    nav:false,
                },
                600:{
                    items:3,
                    nav:false,
                },
                1000:{
                    items:4,
                    nav:true,
                },
                1200:{
                    items:<?php echo esc_attr($related_products_per_view); ?>,
                    nav:true,
                }
            }
        });
    
    });
    </script>



<?php endif;

wp_reset_postdata();
