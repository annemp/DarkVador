To manually import this information into a WordPress site follow these steps:

1. Log in to that site as an administrator.
2. Go to Tools: Import in the WordPress admin panel.
3. Install the "WordPress" importer from the list.
4. Activate & Run Importer.
5. Upload this file (content.xml) from /Theme Import Data/ folder using the form provided on that page.
6. You will first be asked to map the authors in this export file to users on the site. For each author, you may choose to map to an existing user on the site or to create a new user.
7. WordPress will then import each of the posts, pages, products, comments, categories, etc. contained in this file into your site.
8. To import demo widgets install ‘Widget Importer & Exporter’ plugin and select widgets.wie click Import Widgets button.