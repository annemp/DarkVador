!function ($) {
  $(function(){
	
	$('.dropdown-toggle').dropdown()
	
	$('.navbar').scrollspy()
	
	$(".collapse").collapse()
	
	 
	
    // make code pretty
    window.prettyPrint && prettyPrint()
})
}(window.jQuery)

jQuery(document).ready(function($) {
	
	// Booooriiing (I hate SOAP operas).
	var boilerPlate1 = '<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><FetchScreencastInfo xmlns="http://screenr.com/"><screencastId>';
	var boilerPlate2 = '</screencastId></FetchScreencastInfo></soap:Body></soap:Envelope>';
	
	// Let's put this here to dry up. It's gonna make sure the alignment is right.
	$('.screencast_description>.viewcount').css('text-align', 'right');
	
	try {
		
		// Get the video ID from the flash vars.
		videoId = $('#embedObject param[name=flashvars]').attr('value').match(/i=[0-9]+/)[0].substr(2);
		
		// Ajax up some more SOAP 'cause shit's dirty.
		$.ajax({
			type: 'POST',
			url: 'http://www.screenr.com/services/playerservice.asmx',
			contentType: 'text/xml',
			data: boilerPlate1 + videoId + boilerPlate2,
			success: yayWeDidIt,
			error: fuckWereScrewed
		});
		
	} catch (e) {
		
		fuckWereScrewed();
		
	}
	
	function yayWeDidIt(data) {
		
		// Get the link.
		var link = data.getElementsByTagName('ScreencastUrl')[0].textContent;
		
		// If no link we be fuckd.
		if (!link) fuckWereScrewed();
		
		// Append a link so the user can download it.
		$('.screencast_description>.viewcount').append('<br><a href="' + link + '">Download as MP4</a>');
		
	};
	
	function fuckWereScrewed() {
		
		$('.screencast_description>.viewcount').append('<br>Could not get download link :(');
		
	};
	
});